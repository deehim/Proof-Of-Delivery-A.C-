//
//  ListVC.m
//  ProofOfConcept
//
//  Created by SYS-27 on 11/02/18.
//  Copyright © 2018 SYS-27. All rights reserved.
//
#define Screen_height  [UIScreen mainScreen].bounds.size.height
#define Screen_width  [UIScreen mainScreen].bounds.size.width

#import "ListVC.h"
#import <UIImageView+WebCache.h>

@interface ListVC ()<UITableViewDelegate,UITableViewDataSource>{
    NSMutableArray *responseArray;
    UIRefreshControl *refreshControler;
    UITableView * tableView;
}
@end

@implementation ListVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    responseArray=[[NSMutableArray alloc] init];
    refreshControler = [[UIRefreshControl alloc] init];
     _activityIndicator.hidden=NO;
    [_activityIndicator startAnimating];
   
    tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-60) style:UITableViewStylePlain];
    [tableView setDataSource:self];
    [tableView setDelegate:self];
    [tableView setShowsVerticalScrollIndicator:NO];
    tableView.translatesAutoresizingMaskIntoConstraints = NO;
    tableView.rowHeight = UITableViewAutomaticDimension;
    [tableView setAutoresizingMask:UIViewAutoresizingFlexibleHeight];
    [tableView setAutoresizingMask:UIViewAutoresizingFlexibleWidth];
    [self.view addSubview:tableView];
    
    if ([[UIDevice currentDevice].model isEqualToString:@"iPad"] || [[UIDevice currentDevice].model isEqualToString:@"ipad"]) {
        tableView.estimatedRowHeight = 110.0;
    } else {
        tableView.estimatedRowHeight = 65.0;
    }
    
    if (@available(iOS 10.0, *)) {
        tableView.refreshControl = refreshControler;
    }
    [refreshControler addTarget:self action:@selector(pullToRefresh:) forControlEvents:UIControlEventValueChanged];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.rowHeight = UITableViewAutomaticDimension;
   //tableView.estimatedRowHeight = 68;
    
    dispatch_async(dispatch_get_main_queue(), ^{
        //-- To show the network indicator until the process is running.
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    });
    [self getListService];
}

#pragma UIRefreshControl Action
- (IBAction)pullToRefresh:(id)sender {
    [refreshControler beginRefreshing];
    dispatch_async(dispatch_get_main_queue(), ^{
        //-- To show the network indicator until the process is running.
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    });
    [self getListService];
}
#pragma Service Call Method
-(void)getListService{
    NSCharacterSet *expectedCharSet = [NSCharacterSet URLQueryAllowedCharacterSet];
    NSString *urlString = [@"https://dl.dropboxusercontent.com/s/2iodh4vg0eortkl/facts.json" stringByAddingPercentEncodingWithAllowedCharacters:expectedCharSet];
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURL *url = [NSURL URLWithString:urlString];
    NSURLSessionDataTask *dataTask = [session dataTaskWithURL:url completionHandler:^(NSData* data, NSURLResponse* response, NSError *error){
        if(data != nil){
            NSString *latinString = [[NSString alloc] initWithData:data encoding:NSISOLatin1StringEncoding];
            NSData *jsonData = [latinString dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *json = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableLeaves error:&error];
            NSLog(@"response = %@",json);
            dispatch_async(dispatch_get_main_queue(), ^(void){
                _activityIndicator.hidden=YES;
               [_activityIndicator stopAnimating];
               [refreshControler endRefreshing];
               self.navigationItem.title = [json valueForKey:@"title"];
               responseArray=[json valueForKey:@"rows"];
                [tableView reloadData];
            });
        }else{
            UIAlertController *alertController = [UIAlertController  alertControllerWithTitle:@"POC"  message:@"No Internet Connection Available!"  preferredStyle:UIAlertControllerStyleAlert];
            [alertController addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                [self dismissViewControllerAnimated:YES completion:nil];
            }]];
            [self presentViewController:alertController animated:YES completion:nil];
        }
    }];
    [dataTask resume];
}
- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 150;
    
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [responseArray count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *titleStr=[[responseArray objectAtIndex:indexPath.row] valueForKey:@"title"];
    NSString *descriptionStr=[[responseArray objectAtIndex:indexPath.row] valueForKey:@"description"];
    NSString *imgStr=[[responseArray objectAtIndex:indexPath.row]valueForKey:@"imageHref"];
    
    static NSString *reuseIdentifier = @"reuseIdentifier";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    if (cell == nil) {
        //-- Configure the cell if not available
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:reuseIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.detailTextLabel.numberOfLines = 0;
        cell.detailTextLabel.textColor = [UIColor lightGrayColor];
        cell.imageView.contentMode = UIViewContentModeScaleAspectFit;
        if ([[UIDevice currentDevice].model isEqualToString:@"iPad"] || [[UIDevice currentDevice].model isEqualToString:@"ipad"]) {
            cell.detailTextLabel.font = [UIFont fontWithName:cell.detailTextLabel.font.familyName size:cell.detailTextLabel.font.pointSize + 8.0];
            cell.textLabel.font = [UIFont fontWithName:cell.textLabel.font.familyName size:cell.textLabel.font.pointSize+ 8.0];
        }
    }
   
        if (![titleStr isKindOfClass:[NSNull class]]) {
            if ([titleStr length] > 0) {
                cell.textLabel.text = [[responseArray objectAtIndex:indexPath.row] valueForKey:@"title"];
            }
        } else {
            cell.textLabel.text = @"No title available";
        }
        if (![descriptionStr isKindOfClass:[NSNull class]]) {
            if ([descriptionStr length] > 0) {
              cell.detailTextLabel.text=[[responseArray objectAtIndex:indexPath.row] valueForKey:@"description"];
            }
        } else {
            cell.detailTextLabel.text = @"No description available";
        }
    @try {
        if (responseArray.count > 0) {
            //-- To display the title text
            if (![titleStr isEqual:[NSNull null]] && [titleStr length] > 0) {
                cell.textLabel.text = titleStr;
            } else {
                cell.textLabel.text = @"No title available";
            }
            //-- To display the description text
            if (![descriptionStr isEqual:[NSNull null]] && [descriptionStr length] > 0) {
                cell.detailTextLabel.text = descriptionStr;
            } else {
                cell.detailTextLabel.text = @"No description available.";
            }
            
            if (![imgStr isEqual:[NSNull null]] && [imgStr length] > 0) {
                __unsafe_unretained __typeof(cell)POCCell = cell;
            
                [cell.imageView sd_setImageWithURL:[NSURL URLWithString:imgStr] completed:^(UIImage * _Nullable image, NSError * _Nullable error, SDImageCacheType cacheType, NSURL * _Nullable imageURL) {
                    if (image) {
                            if ([[UIDevice currentDevice].model isEqualToString:@"iPad"] || [[UIDevice currentDevice].model isEqualToString:@"ipad"]) {
                                POCCell.imageView.image = [self imageWithImage:image scaledToSize:CGSizeMake(100.0, 100.0)];
                            } else {
                                POCCell.imageView.image = [self imageWithImage:image scaledToSize:CGSizeMake(60.0, 60.0)];
                            }
                       
                    } else {
                     __unsafe_unretained __typeof(cell)POCCell = cell;
                        UIImage * image1=[UIImage imageNamed:@"noimage"];
                        if ([[UIDevice currentDevice].model isEqualToString:@"iPad"] || [[UIDevice currentDevice].model isEqualToString:@"ipad"]) {
                            POCCell.imageView.image = [self imageWithImage:image1 scaledToSize:CGSizeMake(100.0, 100.0)];
                        } else {
                            POCCell.imageView.image = [self imageWithImage:image1 scaledToSize:CGSizeMake(60.0, 60.0)];
                        }
                    }
                    [POCCell layoutSubviews];
                    [POCCell setNeedsLayout];
                }];
            } else {
                __unsafe_unretained __typeof(cell)POCCell = cell;
                UIImage * image=[UIImage imageNamed:@"noimage"];
                if ([[UIDevice currentDevice].model isEqualToString:@"iPad"] || [[UIDevice currentDevice].model isEqualToString:@"ipad"]) {
                    POCCell.imageView.image = [self imageWithImage:image scaledToSize:CGSizeMake(100.0, 100.0)];
                } else {
                    POCCell.imageView.image = [self imageWithImage:image scaledToSize:CGSizeMake(60.0, 60.0)];
                }
                [POCCell layoutSubviews];
                [POCCell setNeedsLayout];
            }
        }
    } @catch (NSException *exception) {
        NSLog(@"An exception occurred due to %@", exception.reason);
    } @finally {
        return cell;
    }
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *imgStr=[[responseArray objectAtIndex:indexPath.row]valueForKey:@"imageHref"];
    NSString *titleStr=[[responseArray objectAtIndex:indexPath.row] valueForKey:@"title"];
    NSString *descriptionStr=[[responseArray objectAtIndex:indexPath.row] valueForKey:@"description"];
    
    UIViewController *vc = [[UIViewController alloc] init];
    [vc.view setBackgroundColor:[UIColor whiteColor]];
    
    UIView  *manaView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, Screen_width , Screen_height)] ;
    manaView.backgroundColor = [UIColor whiteColor];
    [manaView setAutoresizingMask:UIViewAutoresizingFlexibleHeight];
    [manaView setAutoresizingMask:UIViewAutoresizingFlexibleWidth];

    
    UIScrollView *scroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, Screen_width , Screen_height)];
    scroll.contentSize = CGSizeMake(Screen_width, 800);
    scroll.showsHorizontalScrollIndicator = YES;
    [scroll setShowsHorizontalScrollIndicator:NO];
    [scroll setShowsVerticalScrollIndicator:NO];
    [scroll setAutoresizingMask:UIViewAutoresizingFlexibleHeight];
    [scroll setAutoresizingMask:UIViewAutoresizingFlexibleWidth];
    [manaView addSubview:scroll];
 
    
    UIImageView *imageImg = [[UIImageView alloc]init];
    imageImg.frame = CGRectMake(0,30,Screen_width,250);
    imageImg.contentMode=UIViewContentModeScaleAspectFit;
    [imageImg setAutoresizingMask:UIViewAutoresizingFlexibleHeight];
    [imageImg setAutoresizingMask:UIViewAutoresizingFlexibleWidth];
    [vc.view addSubview:manaView];
    [scroll addSubview:imageImg];
    
    UILabel *nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(8, 310, 359, 20)];
    nameLabel.font = [UIFont fontWithName:@"" size:14]; //custom font
    nameLabel.numberOfLines = 0;
    nameLabel.lineBreakMode = NSLineBreakByWordWrapping;
    nameLabel.baselineAdjustment = YES;
    nameLabel.adjustsFontSizeToFitWidth = YES;
    nameLabel.clipsToBounds = YES;
    nameLabel.textColor = [UIColor blackColor];
    nameLabel.textAlignment = NSTextAlignmentLeft;
    [nameLabel setAutoresizingMask:UIViewAutoresizingFlexibleHeight];
    [nameLabel setAutoresizingMask:UIViewAutoresizingFlexibleWidth];
    [scroll addSubview:nameLabel];
    
    UILabel *descriptionLabel = [[UILabel alloc]initWithFrame:CGRectMake(8, 330, 359, 110)];
    [descriptionLabel setFont:[UIFont systemFontOfSize:12]];
    descriptionLabel.numberOfLines = 0;
    descriptionLabel.lineBreakMode = NSLineBreakByWordWrapping;
    descriptionLabel.baselineAdjustment = YES;
    descriptionLabel.adjustsFontSizeToFitWidth = YES;
    descriptionLabel.clipsToBounds = YES;
    descriptionLabel.textColor = [UIColor blackColor];
    descriptionLabel.textAlignment = NSTextAlignmentLeft;
    [descriptionLabel setAutoresizingMask:UIViewAutoresizingFlexibleHeight];
    [descriptionLabel setAutoresizingMask:UIViewAutoresizingFlexibleWidth];
    [scroll addSubview:descriptionLabel];
    
     self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    
    if (![titleStr isKindOfClass:[NSNull class]] && [titleStr length] > 0) {
            nameLabel.text = titleStr;
    }else{
        nameLabel.text = @"No title available right now";
    }
    if (![descriptionStr isKindOfClass:[NSNull class]] && [descriptionStr length] > 0) {
        descriptionLabel.text=descriptionStr;
    }else{
        descriptionLabel.text = @"No description available right now";
    }
    
    if (![imgStr isKindOfClass:[NSNull class]] && [imgStr length] > 0) {
        [imageImg sd_setImageWithURL:[NSURL URLWithString:imgStr] placeholderImage:[UIImage imageNamed: @"noimage"]];
    }else {
        [imageImg sd_setImageWithURL:[NSURL URLWithString:@""] placeholderImage:[UIImage imageNamed:@"noimage"]];
    }
    [self.navigationController pushViewController:vc animated:TRUE];

}
#pragma mark User-defined methods
- (UIImage *)imageWithImage:(UIImage *)image scaledToSize:(CGSize)newSize {

    CGSize size = image.size;
    CGFloat widthRatio  = newSize.width  / image.size.width;
    CGFloat heightRatio = newSize.height / image.size.height;
    if(widthRatio > heightRatio) {
        newSize = CGSizeMake(size.width * heightRatio, size.height * heightRatio);
    } else {
        newSize = CGSizeMake(size.width * widthRatio,  size.height * widthRatio);
    }
    CGRect rect = CGRectMake(0, 0, newSize.width, newSize.height);
    UIGraphicsBeginImageContextWithOptions(newSize, NO, 0.0);
    [image drawInRect:rect];
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
