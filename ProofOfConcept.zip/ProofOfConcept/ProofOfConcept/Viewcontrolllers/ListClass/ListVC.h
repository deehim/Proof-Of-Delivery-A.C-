//
//  ListVC.h
//  ProofOfConcept
//
//  Created by SYS-27 on 11/02/18.
//  Copyright © 2018 SYS-27. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ListVC : UIViewController

@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;
-(void)getListService;
@end
