//
//  AppDelegate.m
//  ProofOfConcept
//
//  Created by SYS-27 on 11/02/18.
//  Copyright © 2018 SYS-27. All rights reserved.
//

#import "AppDelegate.h"
#import "ListVC.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    
    ListVC *obj_factViewController = [[ListVC alloc]initWithNibName:nil bundle:nil];
    //self.loginVC.title = @"Login Page";
    
    self.navigationController = [[UINavigationController alloc]initWithRootViewController:obj_factViewController];
    
    self.navigationController.navigationBar.backgroundColor= [UIColor colorWithRed:115.0/255.0 green:172.0/255 blue:255.0/255 alpha:1.0];
    self.navigationController.navigationBar.barTintColor = [UIColor colorWithRed:115.0/255.0 green:172.0/255 blue:255.0/255 alpha:1.0];
    self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:115.0/255.0 green:172.0/255 blue:255.0/255 alpha:1.0];
    self.navigationController.navigationBar.translucent = NO;
    
    self.window.rootViewController = self.navigationController;
    [self.window makeKeyAndVisible];

//    UIImage *aSplashImage = [UIImage imageNamed:@"LaunchImage"];
//    UIImageView *aSplashImageView = [[UIImageView alloc] initWithFrame:self.window.frame];
//    aSplashImageView.image = aSplashImage;
//
//    UIView *aSplashView = [[UIView alloc]initWithFrame:self.window.frame];
//    [aSplashView addSubview:aSplashImageView];
//
//    [self.window addSubview:aSplashView];
    
//    self.window = [[UIWindow alloc]
//                   initWithFrame:[[UIScreen mainScreen] bounds]];
//   ListVC *obj_factViewController = [[ListVC alloc] init];
//    self.window.rootViewController = obj_factViewController;
//    [self.window makeKeyAndVisible];
    
    
   
    
    
//    //-- Initalize a rootview controller for navigation controller
//    ListVC *obj_factViewController = [[ListVC alloc] init];
//
//    //-- To create an instance of navigation controller to make it as an intiate view controller of window
//    [obj_factViewController.view setBackgroundColor:[UIColor whiteColor]];
//
//    self.navigationController = [[UINavigationController alloc] initWithRootViewController:obj_factViewController];
//
//    //-- To create an instance of a window for an application
//    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].applicationFrame];
//    self.window.backgroundColor = [UIColor whiteColor];
//    //-- Initialize a navigation controller as a key viewcontroller to a window
//    self.window.rootViewController = self.navigationController;
//    [self.window makeKeyAndVisible];
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
